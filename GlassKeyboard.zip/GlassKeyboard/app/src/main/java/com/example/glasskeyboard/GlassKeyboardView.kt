package com.example.glasskeyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.PopupWindow

class GlassKeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(text: String)
        fun onDelete()
        fun onEnter()
    }

    var listener: Listener? = null
    var hasBlur = false
        set(v) { field = v; themeKey = -1; invalidate() }

    private enum class Kind { CHAR, SHIFT, DELETE, LAYER, GLOBE, SPACE, ENTER }
    private enum class Layer { LETTERS, NUM, SYM }
    private class Key(val label: String, val kind: Kind, val weight: Float = 1f, val target: Layer? = null)
    private class Hit(val key: Key, val rect: RectF, val touch: RectF) {
        var fill: Shader? = null
        var stroke: Shader? = null
    }

    private var fa = true
    private var layer = Layer.LETTERS
    private var shift = 0 // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private val hits = ArrayList<Hit>()
    private var pressed: Hit? = null

    // ---- palette ----
    private var dark = false
    private var themeKey = -1
    private var cPanel = 0; private var cKeyTop = 0; private var cKeyBot = 0
    private var cSpTop = 0; private var cSpBot = 0; private var cText = 0
    private var cStrokeTop = 0; private var cStrokeBot = 0; private var cDown = 0; private var cActive = 0

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    private val handler = Handler(Looper.getMainLooper())
    private var repeatDelay = 400L
    private val repeatRunnable = object : Runnable {
        override fun run() {
            listener?.onDelete()
            repeatDelay = (repeatDelay * 0.85f).toLong().coerceAtLeast(40L)
            handler.postDelayed(this, repeatDelay)
        }
    }

    private var popup: PopupWindow? = null

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private fun applyTheme() {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val key = (if (dark) 1 else 0) + (if (hasBlur) 2 else 0)
        if (key == themeKey) return
        themeKey = key
        if (dark) {
            cPanel = Color.argb(if (hasBlur) 70 else 215, 28, 28, 32)
            cKeyTop = Color.argb(70, 255, 255, 255); cKeyBot = Color.argb(38, 255, 255, 255)
            cSpTop = Color.argb(40, 255, 255, 255); cSpBot = Color.argb(22, 255, 255, 255)
            cText = Color.argb(240, 255, 255, 255)
            cStrokeTop = Color.argb(120, 255, 255, 255); cStrokeBot = Color.argb(20, 255, 255, 255)
            cDown = Color.argb(110, 255, 255, 255); cActive = Color.argb(225, 255, 255, 255)
        } else {
            cPanel = Color.argb(if (hasBlur) 60 else 225, 236, 238, 243)
            cKeyTop = Color.argb(190, 255, 255, 255); cKeyBot = Color.argb(120, 255, 255, 255)
            cSpTop = Color.argb(120, 170, 176, 188); cSpBot = Color.argb(80, 170, 176, 188)
            cText = Color.argb(235, 0, 0, 0)
            cStrokeTop = Color.argb(230, 255, 255, 255); cStrokeBot = Color.argb(40, 255, 255, 255)
            cDown = Color.argb(235, 255, 255, 255); cActive = Color.argb(245, 255, 255, 255)
        }
        buildShaders()
    }

    private fun isSpecial(k: Key) = k.kind != Kind.CHAR && k.kind != Kind.SPACE

    private fun buildShaders() {
        for (h in hits) {
            val sp = isSpecial(h.key)
            h.fill = LinearGradient(
                0f, h.rect.top, 0f, h.rect.bottom,
                if (sp) cSpTop else cKeyTop, if (sp) cSpBot else cKeyBot, Shader.TileMode.CLAMP
            )
            h.stroke = LinearGradient(
                0f, h.rect.top, 0f, h.rect.bottom, cStrokeTop, cStrokeBot, Shader.TileMode.CLAMP
            )
        }
    }

    // ---- layouts ----
    private fun chars(s: String) = s.map { Key(it.toString(), Kind.CHAR) }

    private fun buildRows(): List<List<Key>> {
        val bottom = listOf(
            Key(if (layer == Layer.LETTERS) "123" else if (fa) "ابج" else "ABC", Kind.LAYER, 1.3f,
                if (layer == Layer.LETTERS) Layer.NUM else Layer.LETTERS),
            Key("🌐", Kind.GLOBE, 1.3f),
            Key(if (fa) "فاصله" else "space", Kind.SPACE, 4.6f),
            Key(if (fa) "ورود" else "return", Kind.ENTER, 2.1f)
        )
        val del = Key("⌫", Kind.DELETE, 1.4f)
        return when (layer) {
            Layer.LETTERS -> if (fa) listOf(
                chars("ضصثقفغعهخحجچ"), chars("شسیبلاتنمکگ"), chars("ظطزرذدپوئ") + del, bottom
            ) else listOf(
                chars("qwertyuiop"), chars("asdfghjkl"),
                listOf(Key("⇧", Kind.SHIFT, 1.4f)) + chars("zxcvbnm") + del, bottom
            )
            Layer.NUM -> listOf(
                chars(if (fa) "۱۲۳۴۵۶۷۸۹۰" else "1234567890"),
                chars(if (fa) "-/:؛()$&@\"" else "-/:;()$&@\""),
                listOf(Key("#+=", Kind.LAYER, 1.4f, Layer.SYM)) + chars(if (fa) ".،؟!'" else ".,?!'") + del,
                bottom
            )
            Layer.SYM -> listOf(
                chars("[]{}#%^*+="), chars("_\\|~<>€£¥•"),
                listOf(Key("123", Kind.LAYER, 1.4f, Layer.NUM)) + chars(if (fa) ".،؟!'" else ".,?!'") + del,
                bottom
            )
        }
    }

    private fun relayout() {
        hits.clear()
        val w = width.toFloat()
        if (w == 0f) return
        val side = dp(3f); val gap = dp(6f); val vgap = dp(10f); val top = dp(10f); val kh = dp(46f)
        val rows = buildRows()
        val n1 = rows[0].size
        val u = (w - 2 * side - (n1 - 1) * gap) / n1
        rows.forEachIndexed { i, row ->
            val y = top + i * (kh + vgap)
            val chars = row.count { it.kind == Kind.CHAR }
            val flexW = row.filter { it.kind != Kind.CHAR }.sumOf { it.weight.toDouble() }.toFloat()
            val avail = w - 2 * side - (row.size - 1) * gap - chars * u
            val unitFlex = if (flexW > 0) avail / flexW else 0f
            var x = if (flexW == 0f) side + avail / 2 else side
            row.forEachIndexed { j, key ->
                val kw = if (key.kind == Kind.CHAR) u else key.weight * unitFlex
                val r = RectF(x, y, x + kw, y + kh)
                val t = RectF(
                    if (j == 0) 0f else x - gap / 2, y - vgap / 2,
                    if (j == row.size - 1) w else x + kw + gap / 2, y + kh + vgap / 2
                )
                hits.add(Hit(key, r, t))
                x += kw + gap
            }
        }
        themeKey = -1
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (dp(10f) + 4 * dp(46f) + 3 * dp(10f) + dp(10f)).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = relayout()

    // ---- drawing ----
    private fun label(k: Key) =
        if (k.kind == Kind.CHAR && !fa && shift > 0) k.label.uppercase() else if (k.kind == Kind.SHIFT && shift == 2) "⇪" else k.label

    override fun onDraw(c: Canvas) {
        applyTheme()
        panelPaint.color = cPanel
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), panelPaint)
        strokePaint.shader = null
        strokePaint.strokeWidth = dp(0.8f)
        strokePaint.color = cStrokeTop
        c.drawLine(0f, 0f, width.toFloat(), 0f, strokePaint)

        val rad = dp(12f)
        for (h in hits) {
            val k = h.key
            val down = h === pressed
            if (down && k.kind == Kind.CHAR) continue
            val r = h.rect
            // soft fake shadow
            shadowPaint.color = Color.argb(if (dark) 45 else 22, 0, 0, 0)
            c.drawRoundRect(r.left, r.top + dp(1.2f), r.right, r.bottom + dp(1.6f), rad, rad, shadowPaint)
            shadowPaint.color = Color.argb(if (dark) 30 else 14, 0, 0, 0)
            c.drawRoundRect(r.left, r.top + dp(2.2f), r.right, r.bottom + dp(3f), rad, rad, shadowPaint)
            // glass fill
            fillPaint.shader = null
            if (down) fillPaint.color = cDown
            else if (k.kind == Kind.SHIFT && shift > 0) fillPaint.color = cActive
            else fillPaint.shader = h.fill
            c.drawRoundRect(r, rad, rad, fillPaint)
            // glass rim (bright on top, faint at bottom)
            strokePaint.shader = h.stroke
            strokePaint.strokeWidth = dp(1f)
            c.drawRoundRect(r, rad, rad, strokePaint)
            // label
            textPaint.color = if (k.kind == Kind.SHIFT && shift > 0 && dark) Color.BLACK else cText
            textPaint.textSize = when (k.kind) {
                Kind.CHAR -> sp(22f)
                Kind.SPACE, Kind.ENTER, Kind.LAYER -> sp(15f)
                else -> sp(20f)
            }
            val fm = textPaint.fontMetrics
            c.drawText(label(k), r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2, textPaint)
        }
    }

    // ---- touch ----
    private fun hit(x: Float, y: Float): Hit? = hits.firstOrNull { it.touch.contains(x, y) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> press(hit(e.x, e.y))
            MotionEvent.ACTION_UP -> {
                val h = pressed
                release()
                if (h != null) commit(h.key)
            }
            MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    private fun press(h: Hit?) {
        if (h === pressed) return
        handler.removeCallbacks(repeatRunnable)
        hidePopup()
        pressed = h
        if (h != null) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            when (h.key.kind) {
                Kind.CHAR -> showPopup(h)
                Kind.DELETE -> {
                    listener?.onDelete()
                    repeatDelay = 400L
                    handler.postDelayed(repeatRunnable, repeatDelay)
                }
                else -> {}
            }
        }
        invalidate()
    }

    private fun release() {
        handler.removeCallbacks(repeatRunnable)
        hidePopup()
        pressed = null
        invalidate()
    }

    private fun commit(k: Key) {
        when (k.kind) {
            Kind.CHAR -> {
                listener?.onText(label(k))
                if (shift == 1) { shift = 0 }
            }
            Kind.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (shift == 2) 0 else if (now - lastShiftTap < 300) 2 else if (shift == 1) 0 else 1
                lastShiftTap = now
            }
            Kind.LAYER -> { layer = k.target ?: Layer.LETTERS; relayout() }
            Kind.GLOBE -> { fa = !fa; layer = Layer.LETTERS; shift = 0; relayout() }
            Kind.SPACE -> listener?.onText(" ")
            Kind.ENTER -> listener?.onEnter()
            Kind.DELETE -> {}
        }
        invalidate()
    }

    // ---- key bubble ----
    private inner class BubbleView(ctx: Context) : View(ctx) {
        var text = ""; var kx = 0f; var kw = 0f; var kh = 0f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val s = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val headB = h - kh * 0.9f
            val r = dp(12f)
            val path = Path().apply { addRoundRect(RectF(0f, 0f, w, headB), r + dp(4f), r + dp(4f), Path.Direction.CW) }
            val neck = Path().apply { addRect(kx + dp(1f), headB - r, kx + kw - dp(1f), h - kh + r, Path.Direction.CW) }
            val key = Path().apply { addRoundRect(RectF(kx, h - kh, kx + kw, h), r, r, Path.Direction.CW) }
            path.op(neck, Path.Op.UNION); path.op(key, Path.Op.UNION)
            p.color = if (dark) Color.argb(245, 78, 78, 84) else Color.argb(248, 255, 255, 255)
            c.drawPath(path, p)
            s.strokeWidth = dp(1f)
            s.color = if (dark) Color.argb(70, 255, 255, 255) else Color.argb(40, 0, 0, 0)
            c.drawPath(path, s)
            t.color = if (dark) Color.WHITE else Color.BLACK
            t.textSize = sp(34f)
            val fm = t.fontMetrics
            c.drawText(text, w / 2, headB / 2 - (fm.ascent + fm.descent) / 2, t)
        }
    }

    private fun showPopup(h: Hit) {
        if (windowToken == null) return
        val pad = dp(11f)
        val pw = (h.rect.width() + pad * 2).toInt()
        val ph = (h.rect.height() * 2f).toInt()
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val screenW = resources.displayMetrics.widthPixels
        val px = (loc[0] + h.rect.left - pad).coerceIn(0f, (screenW - pw).toFloat())
        val py = loc[1] + h.rect.bottom - ph
        val b = BubbleView(context)
        b.text = label(h.key)
        b.kx = loc[0] + h.rect.left - px
        b.kw = h.rect.width(); b.kh = h.rect.height()
        popup = PopupWindow(b, pw, ph).apply {
            isTouchable = false
            isFocusable = false
            isClippingEnabled = false
            setBackgroundDrawable(null)
            showAtLocation(this@GlassKeyboardView, Gravity.NO_GRAVITY, px.toInt(), py)
        }
    }

    private fun hidePopup() {
        popup?.dismiss()
        popup = null
    }

    override fun onDetachedFromWindow() {
        hidePopup()
        handler.removeCallbacks(repeatRunnable)
        super.onDetachedFromWindow()
    }
}
