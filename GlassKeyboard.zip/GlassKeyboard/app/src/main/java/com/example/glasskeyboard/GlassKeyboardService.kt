package com.example.glasskeyboard

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo

class GlassKeyboardService : InputMethodService(), GlassKeyboardView.Listener {

    private var kb: GlassKeyboardView? = null

    override fun onCreateInputView(): View {
        val v = GlassKeyboardView(this)
        v.listener = this
        kb = v
        setupBlur(v)
        return v
    }

    override fun onEvaluateFullscreenMode() = false

    /** Transparent IME window + background blur (Android 12+, only if the device allows it). */
    private fun setupBlur(v: GlassKeyboardView) {
        val w = window?.window ?: return
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        var blur = false
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val wm = getSystemService(WindowManager::class.java)
                if (wm.isCrossWindowBlurEnabled) {
                    w.setBackgroundBlurRadius(90)
                    blur = true
                }
            } catch (_: Throwable) {
            }
        }
        v.hasBlur = blur
    }

    override fun onText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    override fun onDelete() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun onEnter() {
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei == null || noAction ||
            action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            sendDefaultEditorAction(true)
        }
    }
}
